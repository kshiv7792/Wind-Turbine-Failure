# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 11:36:54 2023

@author: sande
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
data=pd.read_csv('C:/Users/sande/OneDrive/Desktop/DS project2/Wind_turbine.csv')
a=data.describe()  
data.info()  #2 columns date and failure status are object type and rest are float type
data.shape #2900,16
data.columns
data.Failure_status.value_counts() #failure is 500 and non failure is 2400
data['Wind_speed']=abs(data['Wind_speed'])
data['Power']=abs(data['Power'])
data['Rotor_Speed']=abs(data['Rotor_Speed'])
data['Generator_speed']=abs(data['Generator_speed'])
data['Yaw_angle']=abs(data['Yaw_angle'])
data['Wind_direction']=abs(data['Wind_direction'])
a=data.describe()

#EDA
#1st moment of business decision
data.mean()  #17.558490
#=============================================================================
# Power                               3.123788
# Nacelle_ambient_temperature        21.009247
# Generator_bearing_temperature      84.153883
# Gear_oil_temperature               77.649872
# Ambient_temperature                14.080607
# Rotor_Speed                       182.704055
# Nacelle_temperature                45.174112
# Bearing_temperature                81.341528
# Generator_speed                  1419.793976
# Yaw_angle                          45.608925
# Wind_direction                     66.624321
# Wheel_hub_temperature              20.454541
# Gear_box_inlet_temperature         22.978440  
# =============================================================================

data.median()
# =============================================================================
# Wind_speed                         16.625
# Power                               2.790
# Nacelle_ambient_temperature        23.115
# Generator_bearing_temperature      83.365
# Gear_oil_temperature               73.035
# Ambient_temperature                10.210
# Rotor_Speed                       179.820
# Nacelle_temperature                44.910
# Bearing_temperature                70.000
# Generator_speed                  1406.115
# Yaw_angle                          32.845
# Wind_direction                     39.525
# Wheel_hub_temperature              20.415
# Gear_box_inlet_temperature         15.870
# =============================================================================
data.Failure_status.mode()  #no_failure


#2nd moment of business decision
data.var()
# =============================================================================
# Wind_speed                          126.751619
# Power                                 3.876149   spread is less from the mean,most of the power values are near the mean only
# Nacelle_ambient_temperature        1180.807019   spread of temp. is max from mean,most of the data lying away from mean temp.
# Generator_bearing_temperature       470.976619
# Gear_oil_temperature                402.958518
# Ambient_temperature                 573.409601
# Rotor_Speed                       10070.734899 deviation from the mean is max.a wide variary of values are present
# Nacelle_temperature                 392.331904
# Bearing_temperature                 580.654413
# Generator_speed                  187938.410490  deviation from the mean is max.a wide variary of values are present
# Yaw_angle                          1831.611348
# Wind_direction                     6315.682870  deviation from the max here means wide range of wind direction 
# Wheel_hub_temperature              2234.550494  variation of wheel hub temp is more.
# Gear_box_inlet_temperature          537.862573
# =============================================================================

data.std()

# =============================================================================
# Wind_speed                        11.258402
# Power                              1.968794  spread is less,neglegible changes in power from the mean,no big or small unit of power generated
# Nacelle_ambient_temperature       34.362873
# Generator_bearing_temperature     21.701996
# Gear_oil_temperature              20.073827
# Ambient_temperature               23.945973
# Rotor_Speed                      100.353051  huge variety of data is present,spread of data is more from the mean,presence of extreme values could be there
# Nacelle_temperature               19.807370
# Bearing_temperature               24.096772
# Generator_speed                  433.518639  spread is more here,variation in generation speed might be causing turbine failure
# Yaw_angle                         42.797329
# Wind_direction                    79.471271 turbine blades is getting oriented with wide range of wind direction
# Wheel_hub_temperature             47.271032
# Gear_box_inlet_temperature        23.191864
# =============================================================================

# =============================================================================
# data.max()         Wind_speed                        11.258402
# Power                              1.968794
# Nacelle_ambient_temperature       34.362873
# Generator_bearing_temperature     21.701996
# Gear_oil_temperature              20.073827
# Ambient_temperature               23.945973
# Rotor_Speed                      100.353051
# Nacelle_temperature               19.807370
# Bearing_temperature               24.096772
# Generator_speed                  433.518639
# Yaw_angle                         42.797329
# Wind_direction                    79.471271
# Wheel_hub_temperature             47.271032
# Gear_box_inlet_temperature        23.191864
# =============================================================================
data.min()
# =============================================================================
# Wind_speed                              0.0
# Power                                   0.0
# Nacelle_ambient_temperature         -182.94
# Generator_bearing_temperature         10.08
# Gear_oil_temperature                   50.0
# Ambient_temperature                   -20.0
# Rotor_Speed                            0.13
# Nacelle_temperature                  -19.85
# Bearing_temperature                    10.1
# Generator_speed                      302.25
# Yaw_angle                              0.07
# Wind_direction                          0.1
# Wheel_hub_temperature                -89.72
# Gear_box_inlet_temperature             10.0
# =============================================================================

#3rd moment
data.skew()
# =============================================================================
# Wind_speed                       0.718343  few wind_speed values are present in the right side.some high wind spreed values could be causing failure
# Power                            2.438039  during very high generation of power,turbine could be gatting failed 
# Nacelle_ambient_temperature      0.662557  #sometimes high ground temp is causing failure
# Generator_bearing_temperature   -0.125796  it is moderately skewed in the left side means few min generator temp could be causing failure
# Gear_oil_temperature             0.986122  few high gear oil temp. could be causing turbine failure
# Ambient_temperature              1.062682  when outside temp is high turbine is getting failed
# Rotor_Speed                      0.482045  sometimses high speed retation of rotor is causing failure
# Nacelle_temperature             -0.166782  sometimes low ground temp is causing failure
# Bearing_temperature              0.125728  sometimes high bearing temp is causing failure
# Generator_speed                  0.374838  few times when generator speed is more, failure taking place 
# Yaw_angle                        1.362050  when blades getting rotated more against the wind,failure is taking place
# Wind_direction                   2.587978  few times perpendicular direction of wind hitting the blades is causing failure
# Wheel_hub_temperature           -0.085486  this is nearly symmetric,not much variation is there 
# Gear_box_inlet_temperature       2.979123  few high temp of gear box is the cause of failure
# =============================================================================

data.kurt()
# =============================================================================
# Wind_speed                       0.476900  few data are clustered around mean,most of the data are at tail,this shows few high and low speed of wind causing failure
# Power                            6.881044  whenever power generated a lot and least,failure taking place
# Nacelle_ambient_temperature      7.559989  whenever temp of ground is near to max or near to mean,failure taking place
# Generator_bearing_temperature    2.547174   most of speed values are on tail,too less are around mean,high and low value of speed is thre which could be the cause of failure
# Gear_oil_temperature             0.192370  very few high and low gear oil temp could be there
# Ambient_temperature              0.934860   too high outside temp and too cold temp could be there causing failure
# Rotor_Speed                      0.077852  most of data are around clusters,very few high speed or low speed of rotor is there,distribution is nearly symmetric
# Nacelle_temperature              2.366829   most of temp values are on tail,too less are around mean,high and low value of speed is thre which could be the cause of failure
# Bearing_temperature              0.990777   high bearing and low bearing temp is causing failure
# Generator_speed                  2.095680  most of speed values are on tail,too less are around mean,high and low value of speed is thre which could be the cause of failure
# Yaw_angle                        1.245600   few yaw angle values are around mean,very high and very low angle of blades is creating failure
# Wind_direction                   9.096192  too much fluctuation of wind and too less fluctuation is the cause of problem
# Wheel_hub_temperature           -0.260879  only case of platykurtic is this one,modata are clustered around meanst of the 
# Gear_box_inlet_temperature       7.572232  a lot of values are away from mean,huge and least temp of gear box inlet is the cause of failure
# =============================================================================
data.drop(['date_'],axis=1,inplace=True)
data.shape
data.head()
data.duplicated().sum()  #no duplicates present
data['Nacelle_ambient_temperature'].equals(data['Nacelle_temperature'])
data.loc[1:5]
data['match']=data.apply(lambda x:x.Generator_bearing_temperature == x.Gear_oil_temperature == x.Ambient_temperature == x.Nacelle_temperature == x.Bearing_temperature == Gear_box_inlet_temperature ,axis =1  )
data.drop(['match'],axis = 1,inplace = True)
data.isna().sum() #Wind_speed,power,Nacelle_ambient_temperature,Nacelle_temperature ,Generator_speed,Yaw_angle ,Gear_box_inlet_temperature 


#auto eda
pip install sweetviz
import sweetviz as sv
s=sv.analyze(data)
s.show_html()  #gear boil temp,yaw angle,gear box inlet temp are strongly related to failure status

pip install autoviz
from autoviz.AutoViz_Class import AutoViz_Class
av=AutoViz_Class()
a=av.AutoViz(filename='C:/Users/sande/OneDrive/Desktop/DS project2/Wind_turbine.csv')
av.show_html()

pip install dtale
import dtale
d=dtale.show(data)
d.open_browser()

pip install pandas_profiling
from pandas_profiling import ProfileReport
p=ProfileReport(data)
p.to_file('output.html')

pip install dataprep
from dataprep.eda import create_report
report=create_report(data)
report.show_browser()


pip install matplotlib
from sklearn.preprocessing import MinMaxScaler

sns.boxplot(data.Wind_speed)  #outliers present in right side
sns.boxplot(data.Power) ##outliers present in both side
sns.boxplot(data.Nacelle_ambient_temperature) ##outliers present in both side
sns.boxplot(data.Generator_bearing_temperature ) ##outliers present in both side
sns.boxplot(data.Gear_oil_temperature) ##outliers present in upper side
sns.boxplot(data.Ambient_temperature ) ##outliers present in upper side
sns.boxplot(data.Rotor_Speed   ) ## few outliers present in upper side
sns.boxplot(data.Nacelle_temperature)  ##outliers present in both side
sns.boxplot(data.Bearing_temperature)  ### few outliers present in both side
sns.boxplot(data.Generator_speed) ##outliers present in both side
sns.boxplot(data.Yaw_angle) ##outliers present in upper side
sns.boxplot(data.Wind_direction)  ##outliers present in upper side
sns.boxplot(data.Wheel_hub_temperature)  #no outliers present
sns.boxplot(data.Gear_box_inlet_temperature) ##outliers present in upper side

from feature_engine.outliers import Winsorizer
sin=Winsorizer(capping_method='iqr',fold=1.5,tail='both',variables=['Wind_speed','Power','Nacelle_ambient_temperature','Generator_bearing_temperature','Gear_oil_temperature','Ambient_temperature','Rotor_Speed','Nacelle_temperature','Generator_speed','Yaw_angle','Wind_direction','Gear_box_inlet_temperature'])
from sklearn.impute import SimpleImputer
mean_imp = SimpleImputer(missing_values=np.nan,strategy='mean')
data['Wind_speed']=pd.DataFrame(mean_imp.fit_transform(data[["Wind_speed"]]))
data['Nacelle_ambient_temperature']=pd.DataFrame(mean_imp.fit_transform(data[["Nacelle_ambient_temperature"]]))
data['Nacelle_temperature']=pd.DataFrame(mean_imp.fit_transform(data[["Nacelle_temperature"]]))
data['Generator_speed']=pd.DataFrame(mean_imp.fit_transform(data[["Generator_speed"]]))
data['Yaw_angle']=pd.DataFrame(mean_imp.fit_transform(data[["Yaw_angle"]]))
data['Gear_box_inlet_temperature']=pd.DataFrame(mean_imp.fit_transform(data[["Gear_box_inlet_temperature"]]))
data['Power']=pd.DataFrame(mean_imp.fit_transform(data[["Power"]]))

data.isna().sum()
 
data1=sin.fit_transform(data[['Wind_speed','Power','Nacelle_ambient_temperature','Generator_bearing_temperature','Gear_oil_temperature','Ambient_temperature','Rotor_Speed','Nacelle_temperature','Generator_speed','Yaw_angle','Wind_direction','Gear_box_inlet_temperature']])
sns.boxplot(data)
data=pd.concat([data1,data.Bearing_temperature,data.Wheel_hub_temperature,data.Failure_status],axis=1)
data.shape

data.to_csv('cleaned_data.csv')
#check for transformation
import statsmodels.api as sm
import pylab as py
sm.qqplot(data['Wind_speed'], line ='45')
py.show()

sm.qqplot(data['Yaw_angle'], line ='45')
py.show()
data.var()
###min max scalar or normalization
from sklearn.preprocessing import MinMaxScaler
data_x=data.loc[:,data.columns!='Failure_status']
data_y=data.Failure_status


##feature selection  using variance threshold for removing 0 variance features
from sklearn.feature_selection import VarianceThreshold
var0=VarianceThreshold(threshold=0)
var0.fit(data_x)
var0.get_support()  ###true means high variance and false means low variance,here all the features having high variance

round(4.6)

mms=MinMaxScaler()
data_x_norm=mms.fit_transform(data_x)
data_x=pd.DataFrame(data_x_norm,columns=data_x.columns)


##data balancing using SMOTE
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
sm=SMOTE(random_state=12)
data_y.value_counts(normalize=True)*100   ##82.75 is nofailure and 17.24 is failure,data is imbalanced
x_sm, y_sm = sm.fit_resample(data_x, data_y)
y_sm.value_counts(normalize=True)*100 ###50% failure 50% not failure

##feature selection for decreasing inputs
pip install skfeature-chappers
from skfeature.function.similarity_based import fisher_score   #gives the ranks of variables in decreasing order
rank=fisher_score.fisher_score(x_sm,y_sm)
feat_importances=pd.series(rank,x_sm.columns)
idx = fisher_score.fisher_score(x_sm, mode='rank') #returns rank directly instead of fisher score. so no need for feature_ranking
print(idx)

cor=x_sm.corr()
sns.heatmap(cor,annot=True)
