# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 11:36:54 2023

@author: sande
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import StratifiedKFold
from statistics import mean, stdev
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import GaussianNB
from sklearn.feature_selection import VarianceThreshold
from sklearn.model_selection import train_test_split,GridSearchCV
from imblearn.over_sampling import SMOTE
from sklearn.metrics import f1_score
from sklearn.svm import SVC 
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (
    AdaBoostClassifier,
    GradientBoostingClassifier,
    RandomForestClassifier,
    BaggingClassifier,
)
from xgboost import XGBClassifier

data=pd.read_csv('C:/Users/sande/OneDrive/Desktop/DS project2/Wind_turbine.csv')
a=data.describe()  
data.info()  #2 columns date and failure status are object type and rest are float type
data.shape #2900,16
data.columns
data.Failure_status.value_counts() #failure is 500 and non failure is 2400
data['Wind_speed']=abs(data['Wind_speed'])
data['Power']=abs(data['Power'])
data['Rotor_Speed']=abs(data['Rotor_Speed'])
data['Generator_speed']=abs(data['Generator_speed'])
data['Yaw_angle']=abs(data['Yaw_angle'])
data['Wind_direction']=abs(data['Wind_direction'])
a=data.describe()

#EDA
#1st moment of business decision
data.mean()  #17.558490
#=============================================================================
# Power                               3.123788
# Nacelle_ambient_temperature        21.009247
# Generator_bearing_temperature      84.153883
# Gear_oil_temperature               77.649872
# Ambient_temperature                14.080607
# Rotor_Speed                       182.704055
# Nacelle_temperature                45.174112
# Bearing_temperature                81.341528
# Generator_speed                  1419.793976
# Yaw_angle                          45.608925
# Wind_direction                     66.624321
# Wheel_hub_temperature              20.454541
# Gear_box_inlet_temperature         22.978440  
# =============================================================================

data.median()
# =============================================================================
# Wind_speed                         16.625
# Power                               2.790
# Nacelle_ambient_temperature        23.115
# Generator_bearing_temperature      83.365
# Gear_oil_temperature               73.035
# Ambient_temperature                10.210
# Rotor_Speed                       179.820
# Nacelle_temperature                44.910
# Bearing_temperature                70.000
# Generator_speed                  1406.115
# Yaw_angle                          32.845
# Wind_direction                     39.525
# Wheel_hub_temperature              20.415
# Gear_box_inlet_temperature         15.870
# =============================================================================
data.Failure_status.mode()  #no_failure


#2nd moment of business decision
data.var()
# =============================================================================
# Wind_speed                          126.751619
# Power                                 3.876149   spread is less from the mean,most of the power values are near the mean only
# Nacelle_ambient_temperature        1180.807019   spread of temp. is max from mean,most of the data lying away from mean temp.
# Generator_bearing_temperature       470.976619
# Gear_oil_temperature                402.958518
# Ambient_temperature                 573.409601
# Rotor_Speed                       10070.734899 deviation from the mean is max.a wide variary of values are present
# Nacelle_temperature                 392.331904
# Bearing_temperature                 580.654413
# Generator_speed                  187938.410490  deviation from the mean is max.a wide variary of values are present
# Yaw_angle                          1831.611348
# Wind_direction                     6315.682870  deviation from the max here means wide range of wind direction 
# Wheel_hub_temperature              2234.550494  variation of wheel hub temp is more.
# Gear_box_inlet_temperature          537.862573
# =============================================================================

data.std()

# =============================================================================
# Wind_speed                        11.258402
# Power                              1.968794  spread is less,neglegible changes in power from the mean,no big or small unit of power generated
# Nacelle_ambient_temperature       34.362873
# Generator_bearing_temperature     21.701996
# Gear_oil_temperature              20.073827
# Ambient_temperature               23.945973
# Rotor_Speed                      100.353051  huge variety of data is present,spread of data is more from the mean,presence of extreme values could be there
# Nacelle_temperature               19.807370
# Bearing_temperature               24.096772
# Generator_speed                  433.518639  spread is more here,variation in generation speed might be causing turbine failure
# Yaw_angle                         42.797329
# Wind_direction                    79.471271 turbine blades is getting oriented with wide range of wind direction
# Wheel_hub_temperature             47.271032
# Gear_box_inlet_temperature        23.191864
# =============================================================================

# =============================================================================
# data.max()         Wind_speed                        11.258402
# Power                              1.968794
# Nacelle_ambient_temperature       34.362873
# Generator_bearing_temperature     21.701996
# Gear_oil_temperature              20.073827
# Ambient_temperature               23.945973
# Rotor_Speed                      100.353051
# Nacelle_temperature               19.807370
# Bearing_temperature               24.096772
# Generator_speed                  433.518639
# Yaw_angle                         42.797329
# Wind_direction                    79.471271
# Wheel_hub_temperature             47.271032
# Gear_box_inlet_temperature        23.191864
# =============================================================================
data.min()
# =============================================================================
# Wind_speed                              0.0
# Power                                   0.0
# Nacelle_ambient_temperature         -182.94
# Generator_bearing_temperature         10.08
# Gear_oil_temperature                   50.0
# Ambient_temperature                   -20.0
# Rotor_Speed                            0.13
# Nacelle_temperature                  -19.85
# Bearing_temperature                    10.1
# Generator_speed                      302.25
# Yaw_angle                              0.07
# Wind_direction                          0.1
# Wheel_hub_temperature                -89.72
# Gear_box_inlet_temperature             10.0
# =============================================================================

#3rd moment
data.skew()
# =============================================================================
# Wind_speed                       0.718343  few wind_speed values are present in the right side.some high wind spreed values could be causing failure
# Power                            2.438039  during very high generation of power,turbine could be gatting failed 
# Nacelle_ambient_temperature      0.662557  #sometimes high ground temp is causing failure
# Generator_bearing_temperature   -0.125796  it is moderately skewed in the left side means few min generator temp could be causing failure
# Gear_oil_temperature             0.986122  few high gear oil temp. could be causing turbine failure
# Ambient_temperature              1.062682  when outside temp is high turbine is getting failed
# Rotor_Speed                      0.482045  sometimses high speed retation of rotor is causing failure
# Nacelle_temperature             -0.166782  sometimes low ground temp is causing failure
# Bearing_temperature              0.125728  sometimes high bearing temp is causing failure
# Generator_speed                  0.374838  few times when generator speed is more, failure taking place 
# Yaw_angle                        1.362050  when blades getting rotated more against the wind,failure is taking place
# Wind_direction                   2.587978  few times perpendicular direction of wind hitting the blades is causing failure
# Wheel_hub_temperature           -0.085486  this is nearly symmetric,not much variation is there 
# Gear_box_inlet_temperature       2.979123  few high temp of gear box is the cause of failure
# =============================================================================

data.kurt()
# =============================================================================
# Wind_speed                       0.476900  few data are clustered around mean,most of the data are at tail,this shows few high and low speed of wind causing failure
# Power                            6.881044  whenever power generated a lot and least,failure taking place
# Nacelle_ambient_temperature      7.559989  whenever temp of ground is near to max or near to mean,failure taking place
# Generator_bearing_temperature    2.547174   most of speed values are on tail,too less are around mean,high and low value of speed is thre which could be the cause of failure
# Gear_oil_temperature             0.192370  very few high and low gear oil temp could be there
# Ambient_temperature              0.934860   too high outside temp and too cold temp could be there causing failure
# Rotor_Speed                      0.077852  most of data are around clusters,very few high speed or low speed of rotor is there,distribution is nearly symmetric
# Nacelle_temperature              2.366829   most of temp values are on tail,too less are around mean,high and low value of speed is thre which could be the cause of failure
# Bearing_temperature              0.990777   high bearing and low bearing temp is causing failure
# Generator_speed                  2.095680  most of speed values are on tail,too less are around mean,high and low value of speed is thre which could be the cause of failure
# Yaw_angle                        1.245600   few yaw angle values are around mean,very high and very low angle of blades is creating failure
# Wind_direction                   9.096192  too much fluctuation of wind and too less fluctuation is the cause of problem
# Wheel_hub_temperature           -0.260879  only case of platykurtic is this one,modata are clustered around meanst of the 
# Gear_box_inlet_temperature       7.572232  a lot of values are away from mean,huge and least temp of gear box inlet is the cause of failure
# =============================================================================
data.drop(['date_'],axis=1,inplace=True)
data.shape
data.head()
data.duplicated().sum()  #no duplicates present
data['Nacelle_ambient_temperature'].equals(data['Nacelle_temperature'])
data.loc[1:5]
data['match']=data.apply(lambda x:x.Generator_bearing_temperature == x.Gear_oil_temperature == x.Ambient_temperature == x.Nacelle_temperature == x.Bearing_temperature == Gear_box_inlet_temperature ,axis =1  )
data.drop(['match'],axis = 1,inplace = True)
data.isna().sum() #Wind_speed,power,Nacelle_ambient_temperature,Nacelle_temperature ,Generator_speed,Yaw_angle ,Gear_box_inlet_temperature 


#auto eda
pip install sweetviz
import sweetviz as sv
s=sv.analyze(data)
s.show_html()  #gear boil temp,yaw angle,gear box inlet temp are strongly related to failure status

pip install autoviz
from autoviz.AutoViz_Class import AutoViz_Class
av=AutoViz_Class()
a=av.AutoViz(filename='C:/Users/sande/OneDrive/Desktop/DS project2/Wind_turbine.csv')
av.show_html()

pip install dtale
import dtale
d=dtale.show(data_x)
d.open_browser()

pip install pandas_profiling
from pandas_profiling import ProfileReport
p=ProfileReport(data)
p.to_file('output.html')

pip install dataprep
from dataprep.eda import create_report
report=create_report(data)
report.show_browser()


pip install matplotlib
from sklearn.preprocessing import MinMaxScaler

sns.boxplot(data.Wind_speed)  #outliers present in right side
sns.boxplot(data.Power) ##outliers present in both side
sns.boxplot(data.Nacelle_ambient_temperature) ##outliers present in both side
sns.boxplot(data.Generator_bearing_temperature ) ##outliers present in both side
sns.boxplot(data.Gear_oil_temperature) ##outliers present in upper side
sns.boxplot(data.Ambient_temperature ) ##outliers present in upper side
sns.boxplot(data.Rotor_Speed   ) ## few outliers present in upper side
sns.boxplot(data.Nacelle_temperature)  ##outliers present in both side
sns.boxplot(data.Bearing_temperature)  ### few outliers present in both side
sns.boxplot(data.Generator_speed) ##outliers present in both side
sns.boxplot(data.Yaw_angle) ##outliers present in upper side
sns.boxplot(data.Wind_direction)  ##outliers present in upper side
sns.boxplot(data.Wheel_hub_temperature)  #no outliers present
sns.boxplot(data.Gear_box_inlet_temperature) ##outliers present in upper side

from feature_engine.outliers import Winsorizer
sin=Winsorizer(capping_method='iqr',fold=1.5,tail='both',variables=['Wind_speed','Power','Nacelle_ambient_temperature','Generator_bearing_temperature','Gear_oil_temperature','Ambient_temperature','Rotor_Speed','Nacelle_temperature','Generator_speed','Yaw_angle','Wind_direction','Gear_box_inlet_temperature','Bearing_temperature'])
from sklearn.impute import SimpleImputer
mean_imp = SimpleImputer(missing_values=np.nan,strategy='mean')
data['Wind_speed']=pd.DataFrame(mean_imp.fit_transform(data[["Wind_speed"]]))
data['Nacelle_ambient_temperature']=pd.DataFrame(mean_imp.fit_transform(data[["Nacelle_ambient_temperature"]]))
data['Nacelle_temperature']=pd.DataFrame(mean_imp.fit_transform(data[["Nacelle_temperature"]]))
data['Generator_speed']=pd.DataFrame(mean_imp.fit_transform(data[["Generator_speed"]]))
data['Yaw_angle']=pd.DataFrame(mean_imp.fit_transform(data[["Yaw_angle"]]))
data['Gear_box_inlet_temperature']=pd.DataFrame(mean_imp.fit_transform(data[["Gear_box_inlet_temperature"]]))
data['Power']=pd.DataFrame(mean_imp.fit_transform(data[["Power"]]))

data.isna().sum()
 
data1=sin.fit_transform(data[['Wind_speed','Power','Nacelle_ambient_temperature','Generator_bearing_temperature','Gear_oil_temperature','Ambient_temperature','Rotor_Speed','Nacelle_temperature','Generator_speed','Yaw_angle','Wind_direction','Gear_box_inlet_temperature','Bearing_temperature']])
sns.boxplot(data1)
data=pd.concat([data1,data.Wheel_hub_temperature,data.Failure_status],axis=1)
data.shape

data.to_csv('cleaned_data.csv')
#check for transformation
import statsmodels.api as sm
import pylab as py
sm.qqplot(data['Wind_speed'], line ='45')
py.show()

sm.qqplot(data['Yaw_angle'], line ='45')
py.show()
data.var()

###min max scalar or normalization
from sklearn.preprocessing import MinMaxScaler
data_x=data.loc[:,data.columns!='Failure_status']
data_y=data.Failure_status


##feature selection  using variance threshold for removing 0 variance features
from sklearn.feature_selection import VarianceThreshold
var0=VarianceThreshold(threshold=0)
var0.fit(data_x)
var0.get_support()  ###true means high variance and false means low variance,here all the features having high variance

round(4.6)

mms=MinMaxScaler()
data_x_norm=mms.fit_transform(data_x)
data_x_norm=pd.DataFrame(data_x_norm,columns=data_x.columns)

# =============================================================================
# from sklearn.preprocessing import PowerTransformer
# power = PowerTransformer(method='yeo-johnson')
# X=power.fit_transform(data_x_norm)
# X=pd.DataFrame(X,columns=data_x.columns)
# =============================================================================

data_x_norm.hist()

data_x_norm['Wind_direction']=np.sqrt(data_x_norm['Wind_direction'])
# =============================================================================
# data_x_norm['Yaw_angle']=np.sqrt(data_x_norm['Yaw_angle'])
# data_x_norm['Gear_oil_temperature']=np.sqrt(data_x_norm['Gear_oil_temperature'])
# data_x_norm['Gear_box_inlet_temperature']=np.sqrt(data_x_norm['Gear_box_inlet_temperature'])
# =============================================================================
# =============================================================================
# data_x_norm=data_x_norm.drop(['Nacelle_ambient_temperature'],axis=1)
# data_x_norm=data_x_norm.drop(['Nacelle_temperature'],axis=1)
# data_x_norm=data_x_norm.drop(['Generator_speed'],axis=1)
# =============================================================================
data_x_norm['Bearing_temperature']=np.sqrt(data_x_norm['Bearing_temperature'])

# =============================================================================
# data_x_norm=data_x_norm.drop(['Power','Generator_bearing_temperature'],axis=1)
# corrrr=data_x_norm.corr()
# sns.heatmap(corrrr,annot=True)
# 
# =============================================================================

from statsmodels.graphics.gofplots import qqplot
from matplotlib import pyplot
qqplot(X['Wind_speed'], line='s')
pyplot.show()
qqplot(data_x['Wind_speed'], line='s',color='r')
pyplot.show()
##normality check
import math
sm.qqplot(math.log(data_x['Wind_speed']), line ='45')
py.show()
sm.qqplot(math.exp(data['Power']), line ='45')
py.show()

sns.kdeplot(data_x['Wind_speed'])
sns.kdeplot(data['Wind_speed'])
fig,(ob1,ob2) = plt.subplots(ncols=2,figsize=(5,6))
ob1.set_title('before scaling')
ob2.set_title('after scaling')
sns.kdeplot(data['Wind_speed'],ax=ob1)
sns.kdeplot(data_x['Wind_speed'])
sns.kdeplot(data['Power'],ax=ob1)
sns.kdeplot(data_x['Power'])   ##normally distributed compared to before 


##data balancing using SMOTE
from sklearn.model_selection import train_test_split,GridSearchCV
from imblearn.over_sampling import SMOTE
sm=SMOTE(random_state=12)
data_y.value_counts(normalize=True)*100   ##82.75 is nofailure and 17.24 is failure,data is imbalanced
x_sm, y_sm = sm.fit_resample(data_x_norm, data_y)
y_sm.value_counts(normalize=True)*100 ###50% failure 50% not failure

# =============================================================================
# ##feature selection for decreasing inputs
# pip install skfeature-chappers
# from skfeature.function.similarity_based import fisher_score   #gives the ranks of variables in decreasing order
# rank=fisher_score.fisher_score(x_sm,y_sm)
# feat_importances=pd.series(rank,x_sm.columns)
# idx = fisher_score.fisher_score(x_sm, mode='rank') #returns rank directly instead of fisher score. so no need for feature_ranking
# print(idx)
# =============================================================================

cor=x_sm.corr()
sns.heatmap(cor,annot=True)

###MODEL BUILDING USING SEVERAL MODELS
#1.multinomial nb
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import GaussianNB
model_MNB=MultinomialNB()
X_train,X_test,Y_train,Y_test=train_test_split(x_sm,y_sm,test_size=0.2,random_state=30)
model=model_MNB.fit(X_train,Y_train)
predicts_test=model.predict(X_test)
import sklearn.metrics as skmet
#evaluation of testing data
skmet.accuracy_score(Y_test,predicts_test)  ##82.36%
pd.crosstab(Y_test,predicts_test)
#evaluation on training data
predicts_train = model.predict(X_train)
skmet.accuracy_score(Y_train,predicts_train) #83.63%
MultiNB = classification_report(Y_test, predicts_test)

###using hyperparameter tuning for MULTINOMIAL NB MODEL
params = {'alpha': [0.01,0.1,0.001,1,1.5,2,5]}
gd = GridSearchCV(MultinomialNB(), param_grid=params,verbose=1)
gd.fit(X_train, Y_train);
gd.best_params_
gd.best_score_
predicts_test = gd.predict(X_test)
skmet.accuracy_score(Y_test,predicts_test) #82.7
predicts_train = gd.predict(X_train)
skmet.accuracy_score(Y_train,predicts_train) #83.3


accuracy_test=[]
accuracy_train=[]
skf= StratifiedKFold(n_splits=10)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(data_x_norm,data_y):
    print("Train", train_index, "Validation", test_index)
    X_train,X_test=data_x_norm.loc[train_index],data_x_norm.loc[test_index]
    Y_train,Y_test=data_y.loc[train_index],data_y.loc[test_index]
    
                            
    model_MNB.fit(X_train, Y_train)
    prediction_test = model_MNB.predict(X_test)
    prediction_train = model_MNB.predict(X_train)
    score_test=skmet.accuracy_score(prediction_test,Y_test)
    s_train=accuracy_score(prediction_train,Y_train)
    accuracy_test.append(score_test)
    accuracy_train.append(s_train)
    
                            
print(accuracy_test)
print(accuracy_train)
mean(accuracy_test)  #91.37
mean(accuracy_train)  #91.37



accuracy_test=[]
accuracy_train=[]
skf= StratifiedKFold(n_splits=10)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(x_sm,y_sm):
    print("Train", train_index, "Validation", test_index)
    X_train,X_test=x_sm.iloc[train_index],x_sm.iloc[test_index]
    Y_train,Y_test=y_sm.iloc[train_index],y_sm.iloc[test_index]
    
                            
    model_MNB.fit(X_train, Y_train)
    prediction_test = model_MNB.predict(X_test)
    prediction_train = model_MNB.predict(X_train)
    score_test=skmet.accuracy_score(prediction_test,Y_test)
    s_train=accuracy_score(prediction_train,Y_train)
    accuracy_test.append(score_test)
    accuracy_train.append(s_train)
    
                            
print(accuracy_test)
print(accuracy_train)
mean(accuracy_test)  #91.2
mean(accuracy_train)  #91.25

accuracy_test=[]
accuracy_train=[]
skf= StratifiedKFold(n_splits=10)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(x_sm,y_sm):
    print("Train", train_index, "Validation", test_index)
    X_train,X_test=x_sm.iloc[train_index],x_sm.iloc[test_index]
    Y_train,Y_test=y_sm.iloc[train_index],y_sm.iloc[test_index]
    
                            
    gd.fit(X_train, Y_train)
    prediction_test = gd.predict(X_test)
    prediction_train = gd.predict(X_train)
    score_test=skmet.accuracy_score(prediction_test,Y_test)
    s_train=accuracy_score(prediction_train,Y_train)
    accuracy_test.append(score_test)
    accuracy_train.append(s_train)
    
                            
print(accuracy_test)
print(accuracy_train)
mean(accuracy_test)  #91.2
mean(accuracy_train)  #91.25



cm = confusion_matrix(Y_test,prediction_test)
sns.heatmap(cm,
            annot=True,
            fmt='g')
          
plt.ylabel('Prediction',fontsize=13)
plt.xlabel('Actual',fontsize=13)
plt.title('Confusion Matrix',fontsize=17)
plt.show()

MultiNB = classification_report(Y_test, prediction_test)

#Plotting the confusion matrix
plt.figure(figsize=(10,7))
p = sns.heatmap(cm, annot=True, cmap="Reds", fmt='g')


from sklearn.metrics import roc_curve
def plot_roc():
    plt.plot(fpr, tpr, label = 'ROC curve', linewidth = 2)
    plt.plot([0,1],[0,1], 'k--', linewidth = 2)
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve for LoR')
    plt.show()
fpr, tpr, t = roc_curve(Y_test, prediction_test,pos_label='Failure')
plot_roc()


#metrics
# =============================================================================
# =============================================================================
# # precision tells us, out of total predicted positive values how many were actually positive
# # recall tells us, out of total actual negative values how many did our classifier predict negatively
# AUC-ROC Curve is a performance metric that is used to measure the performance for the classification model at different threshold values. ROC is Receiver Operating Characteristic Curve and AUC is Area Under Curve. The higher the value of AUC (Area under the curve), the better is our classifier in predicting the classes. 
# =============================================================================
# =============================================================================
 

## GAUSSIAN NB
model_GNB=GaussianNB()
X_train,X_test,Y_train,Y_test=train_test_split(x_sm,y_sm,test_size=0.2,random_state=12)
model=model_GNB.fit(X_train,Y_train)
predicts_test=model.predict(X_test)
#evaluation of testing data
skmet.accuracy_score(Y_test,predicts_test)  ##87.22%
pd.crosstab(Y_test,predicts_test)
#evaluation on training data
predicts_train = model.predict(X_train)
skmet.accuracy_score(Y_train,predicts_train) #88.6%

##hyperparameter tuning of gausian nb
params_NB = {'var_smoothing': [1e-9, 1e-6, 1e-12]}
gs_nb = GridSearchCV(GaussianNB(), param_grid=params_NB, cv=5, verbose=1)
gs_nb.fit(X_train, Y_train);
gs_nb.best_params_
gs_nb.best_score_
predicts_test = gs_nb.predict(X_test)
skmet.accuracy_score(Y_test,predicts_test)
pd.crosstab(Y_test,predicts_test)


accuracy=[]
skf= StratifiedKFold(n_splits=10,random_state=None)
skf.get_n_splits(data_x,data_y)
for train_index, test_index in skf.split(data_x_norm,data_y):
    print("Train", train_index, "Validation", test_index)
    X1_train,X1_test=data_x_norm.iloc[train_index],data_x_norm.iloc[test_index]
    y1_train,y1_test=data_y.iloc[train_index],data_y.iloc[test_index]
    
                            
    model_GNB.fit(X1_train, y1_train)
    prediction=model_GNB.predict(X1_test)
    score=accuracy_score(prediction,y1_test)
    accuracy.append(score)
                            
print(accuracy)

##################################################################################################

from sklearn.svm import SVC  
model_svm=SVC()
X_train,X_test,Y_train,Y_test=train_test_split(x_sm,y_sm,test_size=0.2,random_state=12)
model=model_svm.fit(X_train,Y_train)
predicts_test=model.predict(X_test)

#evaluation of testing data
skmet.accuracy_score(Y_test,predicts_test)  ##87.22%
pd.crosstab(Y_test,predicts_test)
#evaluation on training data
predicts_train = model.predict(X_train)
skmet.accuracy_score(Y_train,predicts_train) #88.6%

param_grid = {'C': [0.1, 1, 10, 100, 1000], 
              'gamma': [1, 0.1, 0.01, 0.001, 0.0001],
              'kernel': ['rbf']} 
  
grid = GridSearchCV(SVC(), param_grid, refit = True, verbose = 3)
  
# fitting the model for grid search
grid.fit(X_train, Y_train)
predicts_test = grid.predict(X_test)
skmet.accuracy_score(Y_test,predicts_test)

from sklearn.model_selection import StratifiedKFold
from statistics import mean, stdev
from sklearn.metrics import accuracy_score
model_svm=SVC()

accuracy=[]
skf= StratifiedKFold(n_splits=4,random_state=None)
skf.get_n_splits(data_x,data_y)
for train_index, test_index in skf.split(x_sm,y_sm):
    print("Train", train_index, "Validation", test_index)
    X1_train,X1_test=x_sm.iloc[train_index],x_sm.iloc[test_index]
    y1_train,y1_test=y_sm.iloc[train_index],y_sm.iloc[test_index]
    
                            
    grid.fit(X1_train, y1_train)
    prediction=grid.predict(X1_test)
    score=accuracy_score(prediction,y1_test)
    accuracy.append(score)
                            
print(accuracy)
  

#############################################################################################
#logistic regression
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
lor = LogisticRegression()
X_train,X_test,Y_train,Y_test=train_test_split(x_sm,y_sm,test_size=0.2,random_state=12)
lor.fit(X_train,Y_train)
predicts_test = grid.predict(X_test)
skmet.accuracy_score(Y_test,predicts_test)

#defining search space
space = dict()
space['solver'] = ['newton-cg', 'lbfgs']
space['penalty'] = ['none', 'l1', 'l2', 'elasticnet']
space['C'] = [1,10, 20, 100]

model= GridSearchCV(lor, space, scoring='accuracy', n_jobs=-1)
Y_train.value_counts()
model.fit(X_train, Y_train)
model.best_params_
predicts_test=model.predict(X_test)
import sklearn.metrics as skmet
#evaluation of testing data
skmet.accuracy_score(Y_test,predicts_test)  ##87.22%
pd.crosstab(Y_test,predicts)
#evaluation on training data
predicts_train = model.predict(X_train)
skmet.accuracy_score(Y_train,predicts_train) #88.6%

accuracy=[]
skf= StratifiedKFold(n_splits=10,random_state=None)
skf.get_n_splits(data_x,data_y)
for train_index, test_index in skf.split(data_x_norm,data_y):
    print("Train", train_index, "Validation", test_index)
    X1_train,X1_test=data_x_norm.iloc[train_index],data_x_norm.iloc[test_index]
    y1_train,y1_test=data_y.iloc[train_index],data_y.iloc[test_index]
    
                            
    lor.fit(X1_train, y1_train)
    prediction=lor.predict(X1_test)
    score=accuracy_score(prediction,y1_test)
    accuracy.append(score)
                            
print(accuracy)
  

###################################################################################
from sklearn.neighbors import KNeighborsClassifier
model_knn = KNeighborsClassifier()
model_knn.fit(X_train,Y_train)
pred=model_knn.predict(X_test)
skmet.accuracy_score(pred,Y_test)

accuracy=[]
skf= StratifiedKFold(n_splits=10,random_state=None)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(data_x_norm,data_y):
    print("Train", train_index, "Validation", test_index)
    X1_train,X1_test=data_x_norm.iloc[train_index],data_x_norm.iloc[test_index]
    y1_train,y1_test=data_y.iloc[train_index],data_y.iloc[test_index]
    
                            
    model_knn.fit(X1_train, y1_train)
    prediction=model_knn.predict(X1_test)
    score=skmet.accuracy_score(prediction,y1_test)
    accuracy.append(score)
                            
print(accuracy)


grid_params = { 'n_neighbors' : [5,7,9,11,13,15],
               'weights' : ['uniform','distance'],
               'metric' : ['minkowski','euclidean','manhattan']}
gs = GridSearchCV(KNeighborsClassifier(), grid_params, verbose = 1, cv=3, n_jobs = -1)
g_res = gs.fit(X_train, Y_train)
g_res.best_score_
pred=g_res.predict(X_test)
accuracy_score(pred,Y_test)

##########################################################################################
model_dt = DecisionTreeClassifier(random_state=1)



# Parameter grid to pass in RandomSearchCV
param_dt = {'max_depth': np.arange(2,6),
              'min_samples_leaf': [1, 4, 7], 
              'max_leaf_nodes' : [10,15],
              'min_impurity_decrease': [0.0001,0.001] }


grid = GridSearchCV(model_dt, param_grid=param_dt, cv=5, verbose=1)
grid.fit(X_train, Y_train)
predicts_test = grid.predict(X_test)
skmet.accuracy_score(Y_test,predicts_test)

accuracy_test=[]
accuracy_train=[]
skf= StratifiedKFold(n_splits=8,random_state=None)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(x_sm,y_sm):
    print("Train", train_index, "Validation", test_index)
    X_train,X_test=x_sm.iloc[train_index],x_sm.iloc[test_index]
    Y_train,Y_test=y_sm.iloc[train_index],y_sm.iloc[test_index]
    
                            
    grid.fit(X_train, Y_train)
    prediction_test = grid.predict(X_test)
    prediction_train = grid.predict(X_train)
    score_test=skmet.accuracy_score(prediction_test,Y_test)
    s_train=accuracy_score(prediction_train,Y_train)
    accuracy_test.append(score_test)
    accuracy_train.append(s_train)
    
                            
print(accuracy_test)
print(accuracy_train)
mean(accuracy_test)  
mean(accuracy_train)  

##############################################################################################

model_rf = RandomForestClassifier(random_state=1)

# Parameter grid to pass in RandomSearchCV
param_grid = {
    "n_estimators": [200,250,300],
    "min_samples_leaf": np.arange(1, 4),
    "max_features": [np.arange(0.3, 0.6, 0.1),'sqrt'],
    "max_samples": np.arange(0.4, 0.7, 0.1)
}

grid = GridSearchCV(model_rf, param_grid=param_grid, cv=5, verbose=1)
grid.fit(X_train, Y_train)
predicts_test = grid.predict(X_test)
skmet.accuracy_score(Y_test,predicts_test)

accuracy_test=[]
accuracy_train=[]
skf= StratifiedKFold(n_splits=8,random_state=None)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(data_x_norm,data_y):
    print("Train", train_index, "Validation", test_index)
    X_train,X_test=data_x_norm.iloc[train_index],data_x_norm.iloc[test_index]
    Y_train,Y_test=data_y.iloc[train_index],data_y.iloc[test_index]
    
                            
    grid.fit(X_train, Y_train)
    prediction_test = grid.predict(X_test)
    prediction_train = grid.predict(X_train)
    score_test=skmet.accuracy_score(prediction_test,Y_test)
    s_train=accuracy_score(prediction_train,Y_train)
    accuracy_test.append(score_test)
    accuracy_train.append(s_train)
    
                            
print(accuracy_test)
print(accuracy_train)
mean(accuracy_test)  
mean(accuracy_train)  

######################################################################################
ab_clf = AdaBoostClassifier(random_state=None)
parameters = {
    'n_estimators': [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 20],
    'learning_rate': [(0.97 + x / 100) for x in range(0, 8)],
    'algorithm': ['SAMME', 'SAMME.R']
}
clf = GridSearchCV(ab_clf, parameters, cv=5, verbose=1, n_jobs=-1)
clf.fit(X_train, Y_train)
pred_test=clf.predict(X_test)
accuracy_score(pred_test,Y_test)

accuracy_test=[]
accuracy_train=[]
skf= StratifiedKFold(n_splits=10,random_state=None)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(x_sm,y_sm):
    print("Train", train_index, "Validation", test_index)
    X_train,X_test=x_sm.iloc[train_index],x_sm.iloc[test_index]
    Y_train,Y_test=y_sm.iloc[train_index],y_sm.iloc[test_index]
    
                            
    clf.fit(X_train, Y_train)
    prediction_test = clf.predict(X_test)
    prediction_train = clf.predict(X_train)
    score_test=skmet.accuracy_score(prediction_test,Y_test)
    s_train=accuracy_score(prediction_train,Y_train)
    accuracy_test.append(score_test)
    accuracy_train.append(s_train)
    
                            
print(accuracy_test)
print(accuracy_train)

#####################################################################################

bagg = BaggingClassifier(n_estimators=1200,max_samples= 100,max_features=1)
bagg.fit(X_train,Y_train)
pred_bagg = bagg.predict(X_test)
accuracy_score(Y_test,pred_bagg)
from sklearn.model_selection import RandomizedSearchCV
n_estimators = [100, 300, 500, 800, 1200]
#max_depth = [5, 10, 15, 25, 30]
max_samples = [5, 10, 25, 50, 100]
max_features = [1, 2, 5, 10, 13]

#Creating a dictionary for the hyper parameters
hyperbag = dict(n_estimators = n_estimators, max_samples = max_samples, 
              max_features = max_features)

#Applying GridSearchCV to get the best value for hyperparameters
gridbag = RandomizedSearchCV(bagg, hyperbag, cv = 3, verbose = 1, n_jobs = -1)
bestbag = gridbag.fit(X_train, Y_train)

gridbag.best_params_


pred=bestbag.predict(X_test)
accuracy_score(pred,Y_test)

accuracy_test=[]
accuracy_train=[]
skf= StratifiedKFold(n_splits=8,random_state=None)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(data_x_norm,data_y):
    print("Train", train_index, "Validation", test_index)
    X_train,X_test=data_x_norm.iloc[train_index],data_x_norm.iloc[test_index]
    Y_train,Y_test=data_y.iloc[train_index],data_y.iloc[test_index]
    
                            
    bagg.fit(X_train, Y_train)
    prediction_test = bagg.predict(X_test)
    prediction_train = bagg.predict(X_train)
    score_test=skmet.accuracy_score(prediction_test,Y_test)
    s_train=accuracy_score(prediction_train,Y_train)
    accuracy_test.append(score_test)
    accuracy_train.append(s_train)
    
                            
print(accuracy_test)
print(accuracy_train)
mean(accuracy_test)  

###########################################################################################

from keras.models import Sequential
from keras.layers import Dense
classifier = Sequential()
from sklearn.preprocessing import LabelEncoder
l=LabelEncoder()
Y=l.fit_transform(y_sm)

# Adding the input layer and the first hidden layer
classifier.add(Dense(units = 10, kernel_initializer = 'normal', activation = 'relu', input_dim = 14))

# Adding the second hidden layer
classifier.add(Dense(units = 8, kernel_initializer = 'normal', activation = 'relu'))



# Adding the output layer
classifier.add(Dense(units = 1, kernel_initializer = 'uniform', activation = 'sigmoid'))

# Compiling the ANN | means applying SGD on the whole ANN
classifier.compile(optimizer = 'rmsprop', loss = 'binary_crossentropy', metrics = ['accuracy'])


X_train,X_test,Y_train,Y_test=train_test_split(x_sm,Y,test_size=0.2,random_state=1)
# Fitting the ANN to the Training set
classifier.fit(X_train, Y_train, batch_size = 10, epochs = 10)
score, acc_ = classifier.evaluate(X_train, Y_train,batch_size=10) ###0.49 is the accuracy
score, acc = classifier.evaluate(X_test, Y_test,batch_size=10)


rf_params = {
    'optimizer': ['adam','rmsprop'],
    'activation': ['relu','tanh'],
    'loss': ['mse','mae'],
    'batch_size': [16,32],
    'neurons':[16,32],
    'epochs':[20,50],
    'patience':[2,5]
}

pip install tensorflow scikeras scikit-learn
from scikeras.wrappers import KerasClassifier
def create_model(optimizer='rmsprop', init='glorot_uniform'):
    # create model
    model = Sequential()
    model.add(Dense(12, input_dim=14, kernel_initializer=init, activation='relu'))
    model.add(Dense(8, kernel_initializer=init, activation='relu'))
    model.add(Dense(1, kernel_initializer=init, activation='sigmoid'))
    # Compile model
    model.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['accuracy'])
    return model
model = KerasClassifier(model=create_model, verbose=0)
print(model.get_params().keys())
# grid search epochs, batch size and optimizer
optimizers = ['rmsprop', 'adam']
init = ['glorot_uniform', 'normal', 'uniform']
epochs = [20,50]
batches = [5, 10, 20]
param_grid = dict(optimizer=optimizers, epochs=[40], batch_size=[10], model__init=init)
grid = GridSearchCV(estimator=model, param_grid=param_grid)
grid_result = grid.fit(X_train, Y_train)
# summarize results
print("Best: %f using %s" % (grid_result.best_score_, grid_result.best_params_))
means = grid_result.cv_results_['mean_test_score']
stds = grid_result.cv_results_['std_test_score']
params = grid_result.cv_results_['params']
for mean, stdev, param in zip(means, stds, params):
    print("%f (%f) with: %r" % (mean, stdev, param))
    


#################################################################################################
###Creating Pipeline
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score
skfold= StratifiedKFold(n_splits=10)
model_MNB=MultinomialNB(0.01)
preprocessor=Pipeline(steps=[("imputation_mean",mean_imp),("scaler",mms),('model',model_MNB)])

acc_score = cross_val_score (preprocessor, data_x_norm, data_y, cv = skfold,scoring='accuracy')
acc = acc_score.mean()

preprocessor.fit(X_train, Y_train);
Y_pred = preprocessor.predict(X_test)
Y_pred_train = preprocessor.predict(X_train)
accuracy_score(Y_pred,Y_test)
accuracy_score(Y_pred_train,Y_train)


accuracy_test=[]
accuracy_train=[]
skf= StratifiedKFold(n_splits=10)
skf.get_n_splits(data_x_norm,data_y)
for train_index, test_index in skf.split(data_x_norm,data_y):
    print("Train", train_index, "Validation", test_index)
    X_train,X_test=data_x_norm.loc[train_index],data_x_norm.loc[test_index]
    Y_train,Y_test=data_y.loc[train_index],data_y.loc[test_index]
    
                            
    preprocessor.fit(X_train, Y_train)
    prediction_test = preprocessor.predict(X_test)
    prediction_train = preprocessor.predict(X_train)
    score_test=skmet.accuracy_score(prediction_test,Y_test)
    s_train=accuracy_score(prediction_train,Y_train)
    accuracy_test.append(score_test)
    accuracy_train.append(s_train)
    
                            
print(accuracy_test)
print(accuracy_train)
mean(accuracy_test)  #91.37
mean(accuracy_train)  #91.37

import pickle
pickle.dump(preprocessor, open('model_final.pkl', 'wb'))
pickled_model = pickle.load(open('model_final.pkl', 'rb'))


acc_score = cross_val_score (pickled_model, data_x_norm, data_y, cv = skfold,scoring='accuracy')
acc = acc_score.mean()
